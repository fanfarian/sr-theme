<?php

/**
 * Enqueue scripts and styles.
 */
function sr_child_enqueue_scripts_styles() {

	// Adding fontfaceboserver scripts file in the header
	wp_enqueue_script( 'fontfaceobserver', get_template_directory_uri() . '/library/vendor/fontfaceobserver/fontfaceobserver.js', array( ), '2.0.7', false );	// Fontfaceobserver from https://github.com/bramstein/fontfaceobserver
	wp_enqueue_script( 'sr-fontface', get_stylesheet_directory_uri() . '/assets/js/fontface.min.js', array( 'fontfaceobserver' ), '1.0', false );				// Enqueue custom script

	// Register main stylesheet
	wp_enqueue_style( 'sr-child', get_stylesheet_directory_uri() . '/assets/css/style.css', array(), '', 'all' );

	// Adding custom scripts file in the footer
	wp_enqueue_script( 'sr-child', get_stylesheet_directory_uri() . '/assets/js/sr.min.js', array( 'jquery' ), '1.0', true );
    
}
add_action( 'wp_enqueue_scripts', 'sr_child_enqueue_scripts_styles', 100 );



/**
 * Set Additional Images sizes and add them to the media selector
 * - must be configured.
 */
// require_once(get_stylesheet_directory().'/library/functions/theme-images.php');


/**
 * Related post function based on tags - no need to rely on plugins
 * - use sr_related_posts(); in your template file
 */
// require_once(get_stylesheet_directory().'/library/functions/related-posts.php');


/**
 * Customize the WordPress login menu
 * managed through assets/scss/login.scss
 */
// require_once(get_stylesheet_directory().'/library/functions/login.php');


/**
 * Show custom stuff in dashboard activity widget
 * - must be configured!
 */
// require_once(get_stylesheet_directory().'/library/functions/dashboard-widgets.php');


/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function sr_child_theme_support() {

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
	/*
	add_theme_support( 'post-formats',
		array(
			'aside',             // title less blurb
			'gallery',           // gallery of images
			'link',              // quick link to other site
			'image',             // an image
			'quote',             // a quick quote
			'status',            // a Facebook like status update
			'video',             // video
			'audio',             // audio
			'chat'               // chat transcript
		)
	);
	*/

}
add_action( 'after_setup_theme', 'sr_child_theme_support' );

?>
