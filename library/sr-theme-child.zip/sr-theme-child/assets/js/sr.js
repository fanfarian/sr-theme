/* Custom javascript for the child theme
 *
*/


/* Viewport size for MediaQuery
 *
*/
function viewport() {
    var e = window, a = 'inner';
    if (!('innerWidth' in window )) {
        a = 'client';
        e = document.documentElement || document.body;
    }
    return { width : e[ a+'Width' ] , height : e[ a+'Height' ] };
}


/* Variable Empty
 *
*/
function emptyVariable(data)
{
	var count = 0;

	if(typeof(data) == 'number' || typeof(data) == 'boolean') {
		return false;
	}
	if(typeof(data) == 'undefined' || data === null) {
		return true;
	}
	if(typeof(data.length) != 'undefined') {
		return data.length == 0;
	}
	
	for(var i in data) {
		if(data.hasOwnProperty(i)) {
		  count ++;
		}
	}
	return count == 0;
}



/* jQuery version of $(document).ready(function() {
 *
*/
(function($){

	console.log('jQuery ready');


})(jQuery)
